"use strict";

const form      = document.getElementById("formProducto");
const galeria   = document.getElementById("galeria");
const contador  = document.getElementById("contador");
const busqueda  = document.getElementById("busqueda");
const mensaje   = document.getElementById("mensaje");

const productos = [];

const actualizarContador = () => {
    contador.textContent = `Productos: ${productos.length}`;
};

const crearTarjeta = (producto) => {
    const card = document.createElement("article");
    card.classList.add("card");

    const titulo = document.createElement("h3");
    titulo.textContent = producto.nombre;

    const categoria = document.createElement("p");
    categoria.textContent = `Categoría: ${producto.categoria}`;

    const precio = document.createElement("p");
    precio.textContent = `Precio: $${producto.precio}`;
    const descripcion = document.createElement("p");
    descripcion.textContent = producto.descripcion || "Sin descripción";

    const botonEliminar = document.createElement("button");
    botonEliminar.textContent = "Eliminar";

    botonEliminar.addEventListener("click", () => {
        const indexReal = productos.indexOf(producto);
        productos.splice(indexReal, 1);
        renderizarProductos(productos);
    });

    card.append(titulo, categoria, precio, descripcion, botonEliminar);
    galeria.appendChild(card);
};

const renderizarProductos = (lista) => {
    galeria.textContent = "";
    lista.forEach((producto) => {
        crearTarjeta(producto);
    });
    actualizarContador();
};

form.addEventListener("submit", (event) => {
    event.preventDefault();

    const nombre      = document.getElementById("nombre").value.trim();
    const categoria   = document.getElementById("categoria").value;
    const precio      = document.getElementById("precio").value;
    const descripcion = document.getElementById("descripcion").value.trim();

    if (nombre.length < 3) {
        mensaje.textContent = "El nombre debe tener mínimo 3 caracteres";
        return;
    }
    if (precio === "" || precio < 0) {
        mensaje.textContent = "El precio no puede ser negativo";
        return;
    }

    mensaje.textContent = "";

    const producto = { nombre, categoria, precio, descripcion };
    productos.push(producto);

    renderizarProductos(productos);
    form.reset();
});

busqueda.addEventListener("input", () => {
    const texto     = busqueda.value.toLowerCase();
    const filtrados = productos.filter((producto) =>
        producto.nombre.toLowerCase().includes(texto)
    );
    renderizarProductos(filtrados);
});